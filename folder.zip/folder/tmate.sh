#!/bin/bash

# Download the file

# Extract the tar.gz file
docker build -t latest .

# Change directory
docker run latest